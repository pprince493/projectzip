SELECT * FROM Sales.SalesPerson;
