WITH ActiveCustomers (BusinessEntityID)
AS (
 SELECT DISTINCT C.PersonID
 FROM Sales.Customer C
 JOIN Sales.SalesOrderHeader H
 ON C.CustomerID = H.CustomerID
)
SELECT DISTINCT P.BusinessEntityID, P.LastName, P.MiddleName, P.FirstName
FROM Person.Person P
LEFT JOIN ActiveCustomers A
 ON A.BusinessEntityID = P.BusinessEntityID
WHERE A.BusinessEntityID IS NULL;