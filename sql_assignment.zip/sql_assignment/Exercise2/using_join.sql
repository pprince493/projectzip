SELECT DISTINCT P.BusinessEntityID, P.LastName, P.MiddleName, P.FirstName
FROM Person.Person P
LEFT JOIN Sales.Customer C
 ON P.BusinessEntityID = C.PersonID
LEFT JOIN Sales.SalesOrderHeader H
 ON C.CustomerID = H.CustomerID
WHERE H.SalesOrderID IS NULL